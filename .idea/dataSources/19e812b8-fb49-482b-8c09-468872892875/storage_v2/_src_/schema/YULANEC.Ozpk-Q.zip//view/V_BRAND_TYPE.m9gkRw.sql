create view V_BRAND_TYPE as
  select "BRAND_ID","BRAND_NAME" from brand_type
/

