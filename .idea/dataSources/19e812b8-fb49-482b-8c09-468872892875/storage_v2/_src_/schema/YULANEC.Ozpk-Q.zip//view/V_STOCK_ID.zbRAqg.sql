create view V_STOCK_ID as
  select stock_no,note from stock_id
/

